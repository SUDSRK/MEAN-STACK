import { Employee } from "./Employee";
import { Address } from "./Address";

export class ComponentClass {

    showDetails(objAddress:Address, objEmployee:Employee ) {
         
         objEmployee.displayEmployeeInfo();

    }
}

var objAddress:Address  = new Address("Noida", "UP")
 var objEmployee:Employee= new Employee(111, "Amit", objAddress);
var obj1:ComponentClass = new ComponentClass();
obj1.showDetails(objAddress, objEmployee);

var obj2:ComponentClass = new ComponentClass();
obj2.showDetails(objAddress, objEmployee);

var obj3:ComponentClass = new ComponentClass();
obj3.showDetails(objAddress, objEmployee);
