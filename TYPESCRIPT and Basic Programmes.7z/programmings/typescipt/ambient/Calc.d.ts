declare module CalCThirdParty1 { 
    export class Calc { 
       add(a:number, b:number) : number; 
    }
 }