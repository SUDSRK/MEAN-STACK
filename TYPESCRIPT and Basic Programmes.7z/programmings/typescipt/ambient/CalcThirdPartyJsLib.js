var CalCThirdParty; 
(function (CalCThirdParty) { 
   function add(x, y) { 
      console.log(x + y); 
   } 
   CalCThirdParty.add = add; 
})
(CalCThirdParty || (CalCThirdParty = {}));