/// <reference path = "Calc.d.ts" /> 


var obj1 = new CalCThirdParty1.Calc(); 
//obj.add("Hello", "111"); // compiler error 
console.log(obj1.add(10, 20));