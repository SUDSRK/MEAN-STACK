/// <reference path = "aaa.d.ts" /> 
console.log(empName);
