declare var empName : string;
