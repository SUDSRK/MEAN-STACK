interface Parent1 {
    show():void;
    add():void;
}

interface Parent2 {
    show():void;
    subtract():void;
}

class Demo {
    demo() {
        console.log("i am demo method..")
    }
}


class Child extends Demo implements Parent1, Parent2 {
    display():void {
        console.log("i am display method..")
    }

    show():void {
        console.log("i am show method..");
    }

    add():void {
        console.log("i am show method..")
    }

    subtract():void {
        console.log("i am subtract method..")
    }
}

var childObj = new Child();
childObj.display();
childObj.show();

