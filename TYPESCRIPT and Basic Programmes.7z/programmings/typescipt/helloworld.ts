var message:string = "Hello World";
console.log(message)

console.log(message)
