export class Address {

    city:string;
    state:string;

    constructor(city:string, state:string) {
        this.city = city;
        this.state = state;
    }

    public displayAddress() {
        console.log("City : " + this.city + ",  state : " + this.state)
    }


}