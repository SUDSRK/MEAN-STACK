import { Employee } from "./Employee";
import { Address } from "./Address";

export class ComponentClass {

    showDetails() {
         
         var objEmployee:Employee= new Employee(111, "Amit");
         var objEmployee:Employee= new Employee(111, "Amit");
         var objEmployee:Employee= new Employee(111, "Amit");
         var objEmployee:Employee= new Employee(111, "Amit");
         var objEmployee:Employee= new Employee(111, "Amit");
         objEmployee.displayEmployeeInfo();
    }
}

var obj1:ComponentClass = new ComponentClass();
obj1.showDetails();

obj1.showDetails();

obj1.showDetails();
