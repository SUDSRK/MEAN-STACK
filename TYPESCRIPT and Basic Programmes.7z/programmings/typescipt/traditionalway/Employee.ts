import { Address } from "./Address";

export class Employee {

    id:number;
    name:string;
    address:Address;

    constructor(id:number, name:string, ) {
        this.id = id;
        this.name = name;
        this.address  = new Address("Noida", "UP");
    }

    public displayEmployeeInfo() {
        console.log("id : " + this.id + ",  name : " + this.name)
        this.address.displayAddress();
    }

}