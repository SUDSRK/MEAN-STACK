var num:number = 1; 

for(num = 1; num <= 10; num++) {
   console.log("num from for : " + num)
}

while(num <= 20) { 
   console.log("num from while : " + num)
   num++;
}

do { 
	num++;
   console.log("num from do...while : " + num)
} 
while(num <= 30)



