/************** Interface and Objects *************************/

interface IPerson { 
   firstName:string, 
   lastName:string,
   sayHello():string; // simple way / old way
   sayHi:() => string; // lambada expression of function
} 

var customer:IPerson = { 
   firstName:"Tom",
   lastName:"Hanks",
   sayHello():string {
       return "hello"
   },
   sayHi: ():string => {return "Hi there"} 
} 

console.log("Customer Object ") 
console.log(customer.firstName) 
console.log(customer.lastName) 
console.log(customer.sayHi())  

var employee:IPerson = { 
   firstName:"Jim",
   lastName:"Blakes", 
   sayHello():string {
    return "hello"
},
   sayHi: ():string => {return "Hi!!!"} 
} 
  
console.log("Employee  Object ") 
console.log(employee.firstName) 
console.log(employee.lastName)