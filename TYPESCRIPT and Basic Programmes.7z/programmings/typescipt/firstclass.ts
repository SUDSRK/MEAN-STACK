interface Employee {
    salary():void;
}

class CEO implements Employee {
    salary() {
        console.log("salary function called")
    }

    show() {
        console.log("show function called")
    }
}

var obj = new CEO();
obj.salary();
obj.show();