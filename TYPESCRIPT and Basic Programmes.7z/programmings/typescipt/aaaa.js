var a = 10;
var b = "typescipt";
var c = false;
var d = 111;
console.log("Number 111 : " + a);
