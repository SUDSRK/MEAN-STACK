var id = 66666;
var Employee = /** @class */ (function () {
    function Employee() {
    }
    Employee.prototype.setId = function (id) {
        this.id = id;
    };
    Employee.prototype.displayEmployeeInfo = function () {
        console.log("Your id : " + this.id);
        console.log("Your name : " + this.name);
        console.log("Your salary : " + this.salary);
    };
    return Employee;
}());
var ravi = new Employee();
//ravi.setId(111)
ravi.displayEmployeeInfo();
