import hrmodule = require("./Address");

class Employee implements hrmodule.Address { 
             
	showEmployeeDetail() : void {
		console.log("Hello, Rahul" );
	}
	showAddress() : void {
		console.log("Your Address is, Sector 16, noida");
	}

}

var obj: Employee = new Employee();
obj.showEmployeeDetail();
obj.showAddress();



