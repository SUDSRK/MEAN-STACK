"use strict";
exports.__esModule = true;
var Employee = /** @class */ (function () {
    function Employee() {
    }
    Employee.prototype.showEmployeeDetail = function () {
        console.log("Hello, Rahul");
    };
    Employee.prototype.showAddress = function () {
        console.log("Your Address is, Sector 16, noida");
    };
    return Employee;
}());
var obj = new Employee();
obj.showEmployeeDetail();
obj.showAddress();
