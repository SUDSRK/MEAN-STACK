export interface Address { 
      showAddress();
}  