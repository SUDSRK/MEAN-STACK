

class Shape { // parent
   area:number 
   
   constructor(a:number) { 
      this.area = a;
   }

   private show() : any {
       return "aaa";
   }

} 

class Circle extends Shape { // child class
   disp():void { 
      console.log("Area of the circle:  " + this.area) 
   } 
}
  
var obj2 = new Circle(223); 
obj2.disp()


/******************************* Class inheritance and Method Overriding *************************

class PrinterClass { 
   doPrint():void {
      console.log("doPrint() from Parent called…") 
   } 
} 

class StringPrinter extends PrinterClass { 
   doPrint():void { 
      //super.doPrint() 
      console.log("doPrint() is printing a string…")
   } 
} 

var obj = new StringPrinter() 
obj.doPrint()
********/

/******************************* Classes and Interfaces *********************************/

interface ILoan {    interest:number;
   display():void;
} 

class AgriLoan implements ILoan { 
   interest:number 
   rebate:number 
   
   constructor(interest:number,rebate:number) { 
      this.interest = interest 
      this.rebate = rebate 
   }
   
   display():void { 
      console.log("Interest is : "+this.interest+" Rebate is : "+this.rebate )
   } 
} 

var obj3 = new AgriLoan(10,1)
obj3.display();
