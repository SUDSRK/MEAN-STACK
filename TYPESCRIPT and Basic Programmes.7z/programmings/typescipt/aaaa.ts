let a:number = 10;
var b:string = "typescipt";
var c:boolean = false;
var d:any = 111;

console.log("Number 111 : " + a);