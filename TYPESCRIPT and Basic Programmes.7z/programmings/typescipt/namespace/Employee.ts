/// <reference path = "Address.ts" /> 

namespace hrmodule { 
    class Employee implements Address { 
             
        showEmployeeDetail() : void {
            console.log("Hello, Rahul" );
        }
        showAddress() : void {
            console.log("Your Address is, Sector 16, noida");
        }

    }

    var obj: Employee = new Employee();
    obj.showEmployeeDetail();
    obj.showAddress();
}



