namespace hrmodule { 
   export interface Address { 
      showAddress();
   }
}  