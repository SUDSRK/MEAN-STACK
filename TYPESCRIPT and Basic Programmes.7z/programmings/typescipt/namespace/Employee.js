/// <reference path = "Address.ts" /> 
var hrmodule;
(function (hrmodule) {
    var Employee = /** @class */ (function () {
        function Employee() {
        }
        Employee.prototype.showEmployeeDetail = function () {
            console.log("Hello, Rahul");
        };
        Employee.prototype.showAddress = function () {
            console.log("Your Address is, " + "1111");
        };
        return Employee;
    }());
    hrmodule.Employee = Employee;
    var obj = new Employee();
    obj.showEmployeeDetail();
    obj.showAddress();
})(hrmodule || (hrmodule = {}));
