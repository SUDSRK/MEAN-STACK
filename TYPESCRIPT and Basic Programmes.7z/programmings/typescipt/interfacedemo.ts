interface Employee {
    calculateSalary():void;
}

class Developer implements Employee {
    calculateSalary():void {
        console.log("Your Salary : " + 4);
    }
}

var amit = new Developer();
amit.calculateSalary();