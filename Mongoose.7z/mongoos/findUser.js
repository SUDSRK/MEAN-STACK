var mongoose=require('mongoose');
mongoose.connect("mongodb://localhost:27017/nodetest",function(error){
    console.log("open done"+mongoose.connection.host+"\t"+ mongoose.connection.port)
    if(error){
        console.log("error"+error);
    }else{
        console.log("open done")
    }

    var userSchema = new mongoose.Schema({
        name: String,
        username: { type: String, required: true, unique: true },
        password: { type: String, required: true },
        admin: Boolean,
        address: String
    });

    var User = mongoose.model('user', userSchema);

    User.find({}, function(err, users) {
        if (err) throw err;
      
        // object of all the users
        console.log(users);
      });

});

