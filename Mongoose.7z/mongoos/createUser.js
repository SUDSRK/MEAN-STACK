var mongoose=require('mongoose');

mongoose.connect("mongodb://localhost:27017/nodetest", function(error){
    console.log("open done"+mongoose.connection.host+"\t"+ mongoose.connection.port)
    if(error){
        console.log("error"+error);
    }else{
        console.log("open done")
    }

    var userSchema = new mongoose.Schema({
        name: String,
        username: { type: String, required: true, unique: true },
        password: { type: String, required: true },
        admin: Boolean,
        address: String
    });

    var User = mongoose.model('users', userSchema);

    var newUser = User({
        name: 'Peter Quill',
        username: 'starlord55',
        password: 'password',
        admin: true,
        address:"sector 19, noida"
      });
      
      newUser.save(function(err) {
        if (err) throw err;
      
        console.log('User created!');
      });

});

