var mongoose=require('mongoose');
mongoose.connect("mongodb://localhost:27017/nodetest",function(error){
    console.log("open done"+mongoose.connection.host+"\t"+ mongoose.connection.port)
    if(error){
        console.log("error"+error);
    }else{
        console.log("open done")
    }

    var userSchema = new mongoose.Schema({
        name: String,
        username: { type: String, required: true, unique: true },
        password: { type: String, required: true },
        admin: Boolean,
        address: String
    });

    var User = mongoose.model('user', userSchema);

    // find the user starlord55
    // update him to starlord 88
    User.findOneAndUpdate({ username: 'starlord55' }, { username: '111111' }, function(err, user) {
    if (err) {
        throw err;
    }

    console.log("User updated successfully..")

    // we have the updated user returned to us
    console.log(user);
    });
});

